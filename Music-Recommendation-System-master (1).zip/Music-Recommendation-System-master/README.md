# Music-Recommendation-System
The website involves identifying the diversity in music, analyzing the individual needs and creating information base through integration. The Online Music Recommendation website suggests songs which the users may like, based on the songs that they have previously listened to.
Every logged in user has access to the recommender system. The system will go through the songs that user has previously listened to and rated. Based on this information, it recommends songs to the user. 
The main aim is to provide accurate music recommendations to the user. Recommendation will be provided only after the user rates at least 3 or more songs.

The collaborative filtering code has been implemented in "/Music-Recommendation-System/form-3/AfterCustomerLogin/collaborative_filtering.py" file.

Website has been created by taking [this](http://www.free-css.com/free-css-templates/page203/evento) as the base template.

Collaborative filtering is done by using pearson correlation. [This](http://dataaspirant.com/2015/05/25/collaborative-filtering-recommendation-engine-implementation-in-python/) blog has been referred.
